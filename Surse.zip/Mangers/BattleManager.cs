using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleManager : MonoBehaviour
{
    public List<CardController> playerZone = new List<CardController>();
    public List<CardController> enemyZone = new List<CardController>();

    [SerializeField] private Transform playerParent, enemyParent;

    public bool enemyHasTaunt;

    [SerializeField] private PlayerManager playerManager;

    public GameObject playerCard, enemyCard;

    [SerializeField] private GraveyardManager graveyardManager;

    void Start()
    {
        
    }

    
    void Update()
    {
        Check();
    }

    public void Check()
    {
        for(int i = playerZone.Count-1; i >= 0 ; i--) 
        {
            playerZone.RemoveAt(i);
        }

        for(int i = 0; i < playerParent.childCount; i++) 
        {
            playerZone.Add(playerParent.GetChild(i).GetComponent<CardController>());
        }

        for(int i = enemyZone.Count-1; i >= 0 ; i--) 
        {
            enemyZone.RemoveAt(i);
        }

        for(int i = 0; i < enemyParent.childCount; i++) 
        {
            enemyZone.Add(enemyParent.GetChild(i).GetComponent<CardController>());
        }
    }

    public void Battle()
    {
        playerCard.GetComponent<CardController>().currentHealth -= enemyCard.GetComponent<CardController>().currentAttack;
        enemyCard.GetComponent<CardController>().currentHealth -= playerCard.GetComponent<CardController>().currentAttack;

        playerCard.GetComponent<CardController>().UpdateTexts();    
        enemyCard.GetComponent<CardController>().UpdateTexts();

        playerCard = null;
        enemyCard = null;
    }

    public void RemoveSickness()
    {
        for(int i = 0; i < playerParent.childCount; i++) 
        {
            playerZone[i].summoningSickness = false;
            playerZone[i].canAttack = true;
        }
    }

    public int CalculateDmg()
    {
        int x =0;

        for(int i = 0; i < enemyZone.Count; i++) 
        {
            x += enemyZone[i].card[0].cardAttack;
        }

        return x;
    }

    public void AttackAllEnemies(int dmg)
    {
        for(int i = 0; i < playerZone.Count; i++) 
        {
            enemyZone[i].currentHealth -= 2;
            enemyZone[i].UpdateTexts();
        }

        playerManager.players[1].health -= 2;
        playerManager.UpdateHealth();
    }

}
