using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandManager : MonoBehaviour
{
    public List<CardController> hand = new List<CardController>();
    [SerializeField] private Transform handParent;

    public void Check()
    {
        for(int i = hand.Count-1; i >= 0 ; i--) 
        {
            hand.RemoveAt(i);
        }

        for(int i = 0; i < handParent.childCount; i++) 
        {
            hand.Add(handParent.GetChild(i).GetComponent<CardController>());
        }

        for(int i = 0; i < hand.Count; i++) 
        {
            hand[i].Check();
        }
    }
}
