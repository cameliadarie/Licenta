using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

using TMPro;

public class PlayerManager : MonoBehaviour
{
    public List<Player> players = new List<Player>();

    [SerializeField] private TextMeshProUGUI playerMana, enemyMana, playerHealth, enemyHealth;
    [SerializeField] private GameObject winWindow, loseWindow;

    public int maxHealth;

    void Awake()
    {
        UpdateHealth();
    }

    void Update() // temporary
    {
        UpdateMana();
    }

    /*internal*/ public void AssignTurn(int currentPlayerTurn) // horrible
    {
        foreach (Player p in players)
        {
            p.isTurn = p.ID== currentPlayerTurn;
        }
    }

    public Player FindPlayerByID(int ID)
    {
        Player foundplayer = null; 

        foreach (Player p in players)
        {
            foundplayer= p;
        }
        return foundplayer;
    }

    public void UpdateMana()
    {
        playerMana.text = players[0].currentMana + " / " + players[0].mana;
        enemyMana.text = players[1].currentMana + " / " + players[1].mana;
    }

    public void UpdateHealth()
    {
        playerHealth.text = players[0].health + " HP";
        enemyHealth.text = players[1].health + " HP";
    }

    public void AddMana(int x)
    {
        players[x].currentMana++;
    }

    public void AddMaxMana(int x)
    {
        players[x].mana++;
    }

    public void GetDamagae(int damage, int index) 
    {
        players[index].health -= damage;
        UpdateHealth();
        if(players[index].health <= 0)
        {
            PlayerWin();
        }
    }

    public void PlayerWin()
    {
        winWindow.SetActive(true);
    }

    public void EnemyWin()
    {
        loseWindow.SetActive(true);
    }

    public void Back()
    {
        SceneManager.LoadScene("Menu");
    }

}
