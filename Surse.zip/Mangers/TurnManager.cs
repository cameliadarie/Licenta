using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TMPro;

public class TurnManager : MonoBehaviour
{
    public int currentPlayerTurn;
    [SerializeField] private PlayerManager playerManager;
    [SerializeField] private CardManager cardManager;
    [SerializeField] private HandManager handManager;

    public string turn;
    [SerializeField] private TextMeshProUGUI turnText;

    [SerializeField] private AI ai;
    [SerializeField] private BattleManager battleManager;

    public bool initial;

    private void Start()
    {
        initial = true;

        int x = Random.Range(0, 2);

        if(x == 0) 
        {
            playerManager.AssignTurn(0);
            StartCoroutine(cardManager.DrawCoin(1));

            StartTurn();

        }
        else 
        {
  
            playerManager.AssignTurn(1);
            StartCoroutine(cardManager.DrawCoin(0));

            EndTurn();

        }
    }

    public void StartTurn()
    {
        turn = "Your Turn";
        turnText.text = turn;
        playerManager.players[0].mana ++;
        playerManager.players[0].currentMana = playerManager.players[0].mana;
        if(initial == false)
        cardManager.Draw();
        handManager.Check();
        battleManager.RemoveSickness();
    }

    public void EndTurn()
    {
        turn = "Enemy Turn";
        turnText.text = turn;
        playerManager.players[1].mana ++;
        playerManager.players[1].currentMana = playerManager.players[1].mana;
        if(initial == false)
        StartCoroutine(cardManager.EnemyDrawCard());
        handManager.Check();

        StartCoroutine(Skip());
    }

    IEnumerator Skip()
    {
        ai.CardToPlay();
        yield return new WaitForSeconds(2.5f);
        ai.PlayCard();
        yield return new WaitForSeconds(2.5f);
        ai.TargetToAttack();
        yield return new WaitForSeconds(2.5f);
        ai.AttackTarget();

        StartTurn();
    }
}
