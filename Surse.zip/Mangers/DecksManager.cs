using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TMPro;

public class DecksManager : MonoBehaviour
{
    public List<Card> playerDeck = new List<Card>(); 
    public List<Card> enemyDeck = new List<Card>();

    [SerializeField] private TextMeshProUGUI playerCards, enemyCards;
    [SerializeField] private Database database;

    void Awake()
    {
        for(int i = 0; i < 20; i++) 
        {
            int x = Random.Range(1, 20);
            enemyDeck[i].id = x;
            enemyDeck[i] = database.cardList[enemyDeck[i].id];
        }
    }

    void Start()
    {
        LoadDeckData();
        Shuffle();
    }

    public void UpdateDecks(int playerId)
    {
        if(playerId == 0)
        {
            playerDeck.RemoveAt(playerDeck.Count - 1);
            playerCards.text = playerDeck.Count + "";
        }
        else
        {
            enemyDeck.RemoveAt(enemyDeck.Count - 1);
            enemyCards.text = enemyDeck.Count + "";
        }
    }

    private void LoadDeckData() 
    {
        for(int i = 0; i < 20; i++) 
        {
           playerDeck[i].id = PlayerPrefs.GetInt("Card" + i + "", 99); 
           playerDeck[i] = database.cardList[playerDeck[i].id];
        }
    }

    public void Shuffle()
    {
        print("should shuffle");
    }
    
}
