using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TMPro;

public class GraveyardManager : MonoBehaviour
{
    public List<Card> playerCards = new List<Card>();
    public List<Card> enemyCards = new List<Card>();

    [SerializeField] private TextMeshProUGUI playerText, enemyText;

    public void AddCard(Card card, int owner)
    {
        if(owner == 0) 
        {
            playerCards.Add(card);
        }
        else
        {
            enemyCards.Add(card);
        }

        playerText.text = "" + playerCards.Count;
        enemyText.text = "" + enemyCards.Count;
    }
}
