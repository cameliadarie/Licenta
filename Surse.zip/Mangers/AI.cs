using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI : MonoBehaviour
{
    public List<CardController> hand = new List<CardController>();
    [SerializeField] private Transform handParent;
    [SerializeField] private PlayerManager playerManager;
    [SerializeField] private BattleManager battleManager;

    [SerializeField] private int manaToUse;
    [SerializeField] private List<int> cardsToSummon = new List<int>();
    [SerializeField] private Transform zone;
    [SerializeField] private bool targetPlayer;
    [SerializeField] private int dmg;

    public void CardToPlay()
    {
        manaToUse = playerManager.players[0].currentMana;

        for(int i = cardsToSummon.Count-1; i >= 0 ; i--) 
        {
            cardsToSummon.RemoveAt(i);
        }

        Check();
        for(int j = 0; j < hand.Count; j++) 
        {
            if(hand[j].card[0].cardMana <= playerManager.players[0].currentMana)
            {
                manaToUse -= hand[j].card[0].cardMana;
                cardsToSummon.Add(j);
                break;
            }    
        }
        
    }

    public void PlayCard()
    {
        for(int i = 0; i < cardsToSummon.Count; i++) 
        {
            hand[cardsToSummon[0]].transform.SetParent(zone);
            hand[cardsToSummon[0]].GetComponent<CardController>().isSummoned = true;
        }
    }

    public void TargetToAttack()
    {
        dmg = battleManager.CalculateDmg();
        targetPlayer = true;
    }

    public void AttackTarget()
    {
        playerManager.players[0].health -= dmg;
        playerManager.UpdateHealth();

        if(playerManager.players[0].health <= 0)
        {
            playerManager.EnemyWin();
        }
    }

    public void Check()
    {
        for(int i = hand.Count-1; i >= 0 ; i--) 
        {
            hand.RemoveAt(i);
        }

        for(int i = 0; i < handParent.childCount; i++) 
        {
            hand.Add(handParent.GetChild(i).GetComponent<CardController>());
        }
    }
}
