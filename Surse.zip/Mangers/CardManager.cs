using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardManager : MonoBehaviour
{
    public Transform player1Hand,
        player2Hand;
    public CardController cardControllerPrefab;

    [SerializeField]
    private DecksManager decksManager;

    [SerializeField]
    private HandManager handManager;

    [SerializeField]
    private TurnManager turnManager;

    private void Start()
    {
        StartCoroutine(Initial());
    }

    private IEnumerator Initial()
    {
        yield return new WaitForSeconds(1f);
        for (int i = 0; i < 5; i++)
        {
            Draw();
            EnemyDraw();
            yield return new WaitForSeconds(0.5f);
        }

        if (turnManager.turn == "Your Turn")
        {
            StartCoroutine(DrawCoin(0));
        }
        else
        {
            StartCoroutine(DrawCoin(1));
        }

        turnManager.initial = false;
        yield return new WaitForSeconds(1f);
        handManager.Check();
    }

    public IEnumerator Draw_x(int x)
    {
        for (int i = 0; i < x; i++)
        {
            yield return new WaitForSeconds(0.75f);
            CardController newcard = Instantiate(cardControllerPrefab, player1Hand);
            newcard.transform.localPosition = Vector3.zero;

            decksManager.UpdateDecks(0);
        }
    }

    public void Draw()
    {
        CardController newcard = Instantiate(cardControllerPrefab, player1Hand);
        newcard.transform.localPosition = Vector3.zero;
        newcard.GetComponent<CardController>().card[0].ownerID = 1;
        decksManager.UpdateDecks(0);
    }

    public void EnemyDraw()
    {
        CardController newcard = Instantiate(cardControllerPrefab, player2Hand);
        newcard.transform.localPosition = Vector3.zero;
        newcard.GetComponent<CardController>().canSummon = false;
        newcard.GetComponent<CardController>().card[0].ownerID = 2;
        newcard.GetComponent<CardController>().isYourEnemy = true;
        decksManager.UpdateDecks(1);
    }
   public IEnumerator Draw_x_AI(int x)
    {
        for (int i = 0; i < x; i++)
        {
            yield return new WaitForSeconds(0.75f);
            CardController newcard = Instantiate(cardControllerPrefab, player2Hand);
            newcard.transform.localPosition = Vector3.zero;

            decksManager.UpdateDecks(0);
        }
    }

    public IEnumerator DrawCoin(int who) // COIN ID 99
    {
        yield return new WaitForSeconds(1f);
        yield return new WaitForSeconds(3.5f);

        if (who == 0)
        {
            CardController newcard = Instantiate(cardControllerPrefab, player1Hand);
            CardController cardController = newcard.GetComponent<CardController>();
            cardController.id = 99;
            cardController.GetDataX();
            newcard.transform.localPosition = Vector3.zero;
        }
        else
        {
            CardController newcard = Instantiate(cardControllerPrefab, player2Hand);
            CardController cardController = newcard.GetComponent<CardController>();
            cardController.id = 99;
            cardController.GetDataX();
            newcard.transform.localPosition = Vector3.zero;
        }

        handManager.Check();
    }

    public IEnumerator EnemyDrawCard()
    {
        yield return new WaitForSeconds(0.75f);
        EnemyDraw();
    }
}
