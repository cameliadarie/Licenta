using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCharacter : MonoBehaviour
{
    public void Enter()
    {
        CardController.targetEnemy = true;
    }

    public void Exit()
    {
        CardController.targetEnemy = false;
    }
}
