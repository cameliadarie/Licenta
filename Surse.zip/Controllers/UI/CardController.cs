using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

public class CardController : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler, IDragHandler
{
    public List<Card> card = new List<Card>();
    public Card tmp ;

    [SerializeField] private Image illustration, image;
    [SerializeField] private TextMeshProUGUI cardName, cardDescriprion, cardAttack, cardMana, cardHealth;
    [SerializeField] private Transform originalParent;
    [SerializeField] private GameObject border, enemyBorder;
    public int id;

    [SerializeField] private Database database;
    [SerializeField] private DecksManager decksManager;
    public PlayerManager playerManager;
    [SerializeField] private TurnManager turnManager;
    [SerializeField] private HandManager handManager;
    public BattleManager battleManager;
    [SerializeField] private GraveyardManager graveyardManager;

    public CardManager cardManager;
    public bool summoningSickness, isSummoned;

    public bool canSummon;
    [SerializeField] private Effects effects;
    public static bool targetEnemy;

    public bool isYourEnemy;
    public bool hover;
    public static bool attacking;

    public int currentHealth, currentAttack;

    public bool canAttack;
    public static Transform attackingCard;

    void Awake()
    {
        GetDataX();
        canAttack = true;
    }

    public void GetDataX()
    {
        image = GetComponent<Image>();

        database = GameObject.Find("Database").GetComponent<Database>();
        decksManager = GameObject.Find("Decks Manager").GetComponent<DecksManager>();
        playerManager = GameObject.Find("Player Manager").GetComponent<PlayerManager>();
        turnManager = GameObject.Find("Turn Manager").GetComponent<TurnManager>();
        handManager = GameObject.Find("Hand Manager").GetComponent<HandManager>();
        cardManager = GameObject.Find("Card Manager").GetComponent<CardManager>();
        battleManager = GameObject.Find("Battle Manager").GetComponent<BattleManager>();
        graveyardManager = GameObject.Find("Graveyard Manager").GetComponent<GraveyardManager>();

        if(id != 99)
        {
            if(isYourEnemy == false)
            {
                id = decksManager.playerDeck[decksManager.playerDeck.Count - 1].id;
            }
            else
            {
                id = decksManager.enemyDeck[decksManager.enemyDeck.Count - 1].id;
            }

            card[0].id = database.cardList[id].id;
            card[0].cardName = database.cardList[id].cardName;
            card[0].description = database.cardList[id].description;
            card[0].cardType = database.cardList[id].cardType;
            card[0].cardHealth = database.cardList[id].cardHealth;
            card[0].cardAttack = database.cardList[id].cardAttack;
            card[0].cardMana = database.cardList[id].cardMana;

            card[0].effectsTable = database.cardList[id].effectsTable;    
        }
        else
        { 
            card[0] = database.cardList[database.cardList.Count-1];
        }

        illustration.sprite = card[0].cardIllustration;
        cardName.text = card[0].cardName;
        cardDescriprion.text = card[0].description;
        cardAttack.text = card[0].cardAttack.ToString();
        cardHealth.text = card[0].cardHealth.ToString();
        cardMana.text = card[0].cardMana.ToString();
        originalParent = transform.parent;

        currentHealth = card[0].cardHealth;
        currentAttack = card[0].cardAttack;
    }

    public void UpdateTexts()
    {
        cardAttack.text = currentAttack.ToString();
        cardHealth.text = currentHealth.ToString();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if(attacking == true && isYourEnemy == true && isSummoned == true)
        {
            if(battleManager.playerCard != null)
            battleManager.enemyCard = this.gameObject;

            enemyBorder.SetActive(true);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        battleManager.enemyCard = null;
        hover = false;
        //if(attacking == true && isYourEnemy == true && isSummoned == true)
        enemyBorder.SetActive(false);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if(canSummon){
        if (originalParent.name == $"Player{card[0].ownerID}PlayArea")
        {

        }
        else
        {
            transform.SetParent(transform.root);
            image.raycastTarget = false;
        }
        transform.SetParent(transform.root); //parent of the parent
        image.raycastTarget = false;
        }
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if(canSummon){
        image.raycastTarget = true;
        AnalyzePointerUp(eventData);
        }

        border.SetActive(false);
        enemyBorder.SetActive(false);



        if(battleManager.playerCard != null && battleManager.enemyCard != null)
        {
            battleManager.playerCard.GetComponent<CardController>().summoningSickness = true;
            battleManager.Battle();
        }
     

        attacking = false;

    }

    private void AnalyzePointerUp(PointerEventData eventData)
    {
        if (eventData.pointerEnter.name == $"Player{card[0].ownerID} Area")
        {
            PlayCard(eventData.pointerEnter.transform);
        }
        else
        ReturnCard();

        transform.SetParent(originalParent);
        transform.localPosition = Vector3.zero;
    }

    private void ReturnCard()
    {
        transform.SetParent(originalParent);
        transform.localPosition = Vector3.zero;
    }

    private void PlayCard(Transform playArea)
    {
        transform.SetParent(playArea);
        originalParent = playArea;
        playerManager.players[0].currentMana -= card[0].cardMana;
        handManager.Check();
        canSummon = false;
        isSummoned = true;
        summoningSickness = true;
        effects.UseEffect();
        
    }

    public void OnDrag(PointerEventData eventData)
    {
        if(canSummon == true)
        {
        if (transform.parent == originalParent)
            return;

        transform.position = eventData.position;
        }

        if(isSummoned == true && summoningSickness == false && isYourEnemy == false)
        {
            border.SetActive(true);
            battleManager.playerCard = this.gameObject;
            attacking = true;
            attackingCard = transform;
        }
    }

    public void Check()
    {
        if(turnManager.turn == "Your Turn")
        {
            if(card[0].cardMana <= playerManager.players[0].currentMana)
            {
               canSummon = true;
            }
            else
            {
                canSummon = false;
            }
        }
        else
        {
            canSummon = false;
        }

    }

    void Update()
    {
        //if(canAttack)
        //if(summoningSickness == false)
        //if(attacking == true)
        //{
            if(canAttack && targetEnemy && attacking && attackingCard == transform)
            {
                //if(Input.GetMouseButtonUp(0))
                //{
                playerManager.GetDamagae(currentAttack, 1);
                summoningSickness = true;
                attacking = false;
                targetEnemy = false;
                print("attack");
                canAttack = false;
            }
        //}






        if(isSummoned)
        if(isYourEnemy == false)
        {
            if(this.currentHealth <= 0)
            {
                border.SetActive(false);
                enemyBorder.SetActive(false);
                // graveyardManager.playerCards.Add(card[0]);
                graveyardManager.AddCard(card[0], 0);
                Destroy(this.gameObject);
            }
        }
        else
        {
            if(this.currentHealth <= 0)
            {
                border.SetActive(false);
                enemyBorder.SetActive(false);
                //graveyardManager.enemyCards.Add(card[0]);
                graveyardManager.AddCard(card[0], 1);
                Destroy(this.gameObject);
            }
        }


        
    }

        
    
}
