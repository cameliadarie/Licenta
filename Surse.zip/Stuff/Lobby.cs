using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TMPro;
using UnityEngine.SceneManagement;

public class Lobby : MonoBehaviour
{
    [SerializeField] private int stage;
    [SerializeField] private TextMeshProUGUI waitText;
    [SerializeField] private bool foundEnemy;

    void Awake()
    {
        StartCoroutine(Wait());
        StartCoroutine(Simulate());
    }

    public void Back()
    {
        SceneManager.LoadScene("Decks");
    }

    IEnumerator Wait()
    {
        switch(stage)
        {
            case 1:
                waitText.text = "Waiting for the other Player .";
                break;

            case 2:
                waitText.text = "Waiting for the other Player ..";
                break;

            case 3:
                waitText.text = "Waiting for the other Player ...";
                break;
        }

        if(stage < 3)
        {
            stage++;
        }
        else
        {
            stage = 1;
        }

        if(foundEnemy == true)
        {
            stage = 0;
            StartCoroutine(Play());
        }

        yield return new WaitForSeconds(0.25f);
        StartCoroutine(Wait());
    }

    IEnumerator Play()
    {
        waitText.text = "Preparing Game. Wait";
        yield return new WaitForSeconds(2.5f);

        SceneManager.LoadScene("MainScene");
    }

    IEnumerator Simulate() // Test
    {
        yield return new WaitForSeconds(3f);
        foundEnemy = true;
    }
}
