using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class Decks : MonoBehaviour
{
    [System.Serializable] public class Deck
    {
        public List<Card> deck = new List<Card>();
    }

    public List<Deck> decks = new List<Deck>();

    [SerializeField] private int currentDeck, maxCards;
    [SerializeField] private TextMeshProUGUI[] cards;

    [SerializeField] private Image illustration, image;
    public TextMeshProUGUI cardDescriprion, cardAttack, cardMana, cardHealth;

    void Start()
    {
        Display();
    }

    public void SetDeck(int id)
    {
        currentDeck = id;
        Display();
    }

    public void Display()
    {
        for(int i = 0; i < maxCards; i++) 
        {
            cards[i].text = decks[currentDeck].deck[i].cardName;
        }
    }

    private void CardDisplay(int id)
    {
        cardDescriprion.text = decks[currentDeck].deck[id].description;
        cardAttack.text = decks[currentDeck].deck[id].cardAttack.ToString();
        cardHealth.text = decks[currentDeck].deck[id].cardHealth.ToString();
        cardMana.text = decks[currentDeck].deck[id].cardMana.ToString();
    }

    public void Play()
    {
        SaveDeckData();
        SceneManager.LoadScene("Lobby");
    }

    public void Back()
    {
        SceneManager.LoadScene("Menu");
    }

    public void Enter(int id)
    {
        CardDisplay(id);
    }

    private void SaveDeckData() 
    {
        for(int i = 0; i < 20; i++) 
        {
            PlayerPrefs.SetInt("Card" + i + "", decks[currentDeck].deck[i].id);
        }
    }
}
