using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Effects : MonoBehaviour
{
    public CardController card;

    public void UseEffect()
    {
        if (card.card[0].effectsTable[2] == true)
        {
            card.summoningSickness = false;
        }

        if (card.card[0].effectsTable[3] == true)
        {
            StartCoroutine(card.cardManager.Draw_x(1));
        }

        if (card.card[0].effectsTable[4] == true)
        {
            StartCoroutine(card.cardManager.Draw_x(2));
        }

        if (card.card[0].effectsTable[9] == true)
        {
            card.playerManager.players[0].health += 3;

            if (card.playerManager.players[0].health > card.playerManager.maxHealth)
            {
                card.playerManager.players[0].health = card.playerManager.maxHealth;
            }

            card.playerManager.UpdateHealth();
        }

        if (card.card[0].effectsTable[11] == true)
        {
            card.playerManager.AddMaxMana(0);
        }

        if (card.card[0].effectsTable[12] == true)
        {
            card.playerManager.AddMana(0);
        }

        // if (card.card[0].effectsTable[5] == true)
        // {
        //     card.battleManager.AttackAllEnemies(2);
        // }
    }

    public void UseEffect_AI()
    {
        if (card.card[0].effectsTable[2] == true)
        {
            card.summoningSickness = false;
        }

        if (card.card[0].effectsTable[3] == true)
        {
            StartCoroutine(card.cardManager.Draw_x_AI(1));
        }

        if (card.card[0].effectsTable[4] == true)
        {
            StartCoroutine(card.cardManager.Draw_x_AI(2));
        }

        if (card.card[0].effectsTable[9] == true)
        {
            card.playerManager.players[1].health += 3;

            if (card.playerManager.players[1].health > card.playerManager.maxHealth)
            {
                card.playerManager.players[1].health = card.playerManager.maxHealth;
            }

            card.playerManager.UpdateHealth();
        }

        if (card.card[0].effectsTable[11] == true)
        {
            card.playerManager.AddMaxMana(1);
        }

        if (card.card[0].effectsTable[12] == true)
        {
            card.playerManager.AddMana(1);
        }
        // if (card.card[0].effectsTable[5] == true)
        // {
        // card.battleManager.AttackAllEnemies(2);
        // }
    }
}
