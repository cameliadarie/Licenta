using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Database: MonoBehaviour
{
    public List<Card> cardList;

    void Awake()
    {
        cardList.Add(new Card(0, "minion 0", " ", "minion", 2, 1, 2, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));

        // MINIONS/SPELLS WITH EFFECTS 
        cardList.Add(new Card(1, "Taunt Card", "Has Taunt", "minion", 1, 4, 3, 0, 
        new bool[]{true, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(2, "minion K", " ", "minion", 1, 1, 1, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(3, "Charge Card", "Can attack immediately", "minion", 1, 2, 1, 0, 
        new bool[]{false, false, true, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(4, "Draw Card 1", "Draw 1 card", "minion", 1, 1, 1, 0, 
        new bool[]{false, false, false, true, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(5, "Draw Card 2", "Draw 2 cards", "minion", 2, 2, 2, 0, 
        new bool[]{false, false, false, false, true, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(6, "HellFire", "Deal 2 DMG to all enemies", "spell", 0, 2, 3, 0, 
        new bool[]{false, false, false, false, false, true, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(7, "minion G", " ", "minion", 2, 1, 2, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(8, "minion H", " ", "minion", 5, 5, 5, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(9, "minion I", " ", "minion", 2, 3, 3, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(10, "heal", "Have 3 more health", "minion", 1, 2, 1, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, true, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(11, "minion J", " ", "minion", 1, 1, 1, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(12, "Max Mana", "Add 1 mana to your maxMana", "spell", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, true, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(13, "Current Mana", "Have 1 more mana THIS turn only", "spell", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, true}, Resources.Load <Sprite>("sprite name")));

        // SIMPLE MINIONS
        cardList.Add(new Card(14, "Minion A", " ", "minion", 2, 2, 2, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(15, "Minion B", " ", "minion", 3, 3, 3, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(16, "Minion C", " ", "minion", 4, 4, 4, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(17, "Minion D", " ", "minion", 5, 5, 5, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(18, "Minion E", " ", "minion", 3, 3, 2, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(19, "Minion F", " ", "minion", 7, 7, 7, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));

        // COIN
        cardList.Add(new Card(99, "Coin", "Get 1 Mana THIS turn", "spell", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, true}, Resources.Load <Sprite>("sprite name")));
   
    }


}
