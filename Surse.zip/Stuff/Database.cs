using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Database: MonoBehaviour
{
    public List<Card> cardList;

    void Awake()
    {
        cardList.Add(new Card(0, "no name", "no description", "minion", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));

        // MINIONS/SPELLS WITH EFFECTS 
        cardList.Add(new Card(1, "Taunt Card", "Has Taunt", "minion", 1, 4, 2, 0, 
        new bool[]{true, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(2, "no name", "no description", "none type", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(3, "Charge Card", "charge", "minion", 1, 2, 1, 0, 
        new bool[]{false, false, true, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(4, "Draw Card 1", "draw 1 card", "minion", 1, 1, 1, 0, 
        new bool[]{false, false, false, true, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(5, "Draw Card 2", "draw 2 cards", "minion", 2, 2, 2, 0, 
        new bool[]{false, false, false, false, true, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(6, "HellFire", "Deal 2 DMG to all enemies", "spell", 0, 0, 3, 0, 
        new bool[]{false, false, false, false, false, true, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(7, "no name", "no description", "minion", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(8, "no name", "no description", "minion", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(9, "no name", "no description", "minion", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(10, "Heal Card", "heal", "minion", 8, 8, 1, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, true, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(11, "no name", "no description", "minion", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(12, "Max Mana", "add", "minipn", 1, 2, 3, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, true, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(13, "Current Mana", "add", "minion", 1, 1, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, true}, Resources.Load <Sprite>("sprite name")));

        // SIMPLE MINIONS
        cardList.Add(new Card(14, "Minion A", "A", "minion", 2, 2, 2, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(15, "Minion B", "B", "minion", 3, 3, 3, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(16, "Minion C", "C", "minion", 4, 4, 4, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(17, "Minion D", "D", "minion", 5, 5, 5, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(18, "Minion E", "E", "minion", 6, 6, 6, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));
        cardList.Add(new Card(19, "Minion F", "F", "minion", 7, 7, 7, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, false}, Resources.Load <Sprite>("sprite name")));

        // COIN
        cardList.Add(new Card(99, "Coin", "Get 1 Mana", "spell", 0, 0, 0, 0, 
        new bool[]{false, false, false, false, false, false, false, false, false, false, false, false, true}, Resources.Load <Sprite>("sprite name")));
   
    }


}
