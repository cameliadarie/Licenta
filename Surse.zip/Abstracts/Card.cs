
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Card
{
    public int id;
    public string cardName, description, cardType;
    public int cardHealth, cardAttack, cardMana, ownerID;
    public bool[] effectsTable;
    public Sprite cardIllustration;

    public Card(int Id, string CardName, string Description, string CardType, int CardHealth, int CardAttack, int CardMana, int OwnerID, bool[] EffectsTable, Sprite CardIllustration)
    {
        this.id = Id;
        this.cardName = CardName;
        this.description = Description;
        this.cardType = CardType;
        this.cardHealth = CardHealth;
        this.cardAttack = CardAttack;
        this.cardMana = CardMana;
        this.effectsTable = EffectsTable;
        this.cardIllustration = CardIllustration;
    }
}

