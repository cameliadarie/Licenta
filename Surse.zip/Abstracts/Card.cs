
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Card
{
    public int id;
    public string cardName, description, cardType;
    public int cardHealth, cardAttack, cardMana, ownerID;
    public bool[] effectsTable;
    public Sprite cardIllustration;

    public Card(int Id, string CardName, string Description, string CardType, int CardHealth, int CardAttack, int CardMana, int OwnerID, bool[] EffectsTable, Sprite CardIllustration)
    {
        this.id = Id;
        this.cardName = CardName;
        this.description = Description;
        this.cardType = CardType;
        this.cardHealth = CardHealth;
        this.cardAttack = CardAttack;
        this.cardMana = CardMana;
        //Owner ID later
        this.effectsTable = EffectsTable;
        this.cardIllustration = CardIllustration;
    }
}

// Effects Table
//
// 0 - Taunt               // behaviour
// 1 - Double Attack      // special
// 2 - Charge V
// 3 - Draw 1 V
// 4 - Draw 2 V
// 5 - Damage To All Enemies on Table
// 6 - Damage To one Target [Enemy or Enemy Minion]
// 7 - Freeze All Minions
// 8 - Freeze Minion
// 9 - Heal Player V
// 10 - Heal Your Minion
// 11 - Add MaxMana V
// 12 - Add CurrentMana V


// 0 - 12 << 13 effects
