using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Player
{
    public int health, mana, currentMana;
    public int ID;
    public bool isTurn;

    public Player(int health, int mana, int currentMana, int ID)
    {
        this.health = health;
        this.mana = mana;
        this.currentMana = currentMana;
        this.ID = ID;

    }
}
